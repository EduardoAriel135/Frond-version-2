"""Módulo raíz del frontend."""
